var x = document.getElementsByTagName("p");
for (var i=0;i<x.length;i++){
    x[i].innerHTML="Hi there";
}